import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'

export default function Checkout(){
  const { cart, products, fmt, placeOrder, cartTotal } = useApp()
  const [ship, setShip] = useState({ name:'', phone:'', addr:'', method:'pickup' })
  const [pay, setPay] = useState({ method:'gcash', email:'' })
  const navigate = useNavigate()

  const shippingFee = useMemo(()=> ship.method==='3pl' ? 79 : 0, [ship.method])
  const toPay = cartTotal + shippingFee

  const place = () => {
    const res = placeOrder({ ship, pay })
    if(res.ok){
      alert('Order placed! A confirmation has been sent.')
      navigate('/orders')
    }else{
      alert(res.msg || 'Unable to place order')
    }
  }

  const li = cart.map(i=>{
    const p = products.find(x=>x.id===i.pid)
    return <li key={i.id}>{i.qty}× {p.name} — {fmt(p.price*i.qty)} <span className="muted mini">{i.note || ''}</span></li>
  })

  if(!cart.length) return <div className="panel">Your cart is empty.</div>

  return (
    <div className="grid">
      <div className="panel">
        <div className="tabs">
          <button className="on">1 • Shipping</button>
          <button>2 • Payment</button>
          <button>3 • Review</button>
        </div>
        <div className="grid">
          <div className="row">
            <input placeholder="Full name" value={ship.name} onChange={e=>setShip({...ship, name:e.target.value})} />
            <input placeholder="Mobile" value={ship.phone} onChange={e=>setShip({...ship, phone:e.target.value})} />
          </div>
          <input placeholder="Address (for delivery to seat or home)" value={ship.addr} onChange={e=>setShip({...ship, addr:e.target.value})} />
          <div className="row">
            <select value={ship.method} onChange={e=>setShip({...ship, method:e.target.value})}>
              <option value="pickup">Pick up at counter</option>
              <option value="seat">Deliver to seat</option>
              <option value="3pl">3PL Delivery (Grab/Lalamove)</option>
            </select>
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="row">
          <select value={pay.method} onChange={e=>setPay({...pay, method:e.target.value})}>
            <option value="gcash">GCash</option>
            <option value="maya">Maya</option>
            <option value="card">Credit/Debit (PCI‑simulated)</option>
            <option value="apple">Apple Pay</option>
            <option value="google">Google Pay</option>
          </select>
          <input placeholder="Receipt email" value={pay.email} onChange={e=>setPay({...pay, email:e.target.value})} />
        </div>
        <div className="muted mini">Payments are sandbox‑simulated. No real charges.</div>
      </div>

      <div className="panel">
        <div className="card">
          <b>Items</b>
          <ul>{li}</ul>
          <div><b>Subtotal:</b> {fmt(cartTotal)}</div>
          <div><b>Shipping:</b> {fmt(shippingFee)} ({ship.method})</div>
          <div><b>To Pay:</b> {fmt(toPay)}</div>
          <div className="muted mini">Payment: {pay.method.toUpperCase()} • Email: {pay.email || '—'}</div>
        </div>
        <div className="row" style={{marginTop:8}}>
          <button className="btn ok right" onClick={place}>Place Order</button>
        </div>
      </div>
    </div>
  )
}
