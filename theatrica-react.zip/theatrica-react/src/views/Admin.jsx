import React, { useState } from 'react'
import { useApp } from '../context/AppContext'

export default function Admin(){
  const { admin } = useApp()
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [msg, setMsg] = useState('')

  const login = () => {
    const a = JSON.parse(localStorage.getItem('admin') || 'null')
    if(a && email===a.email && pass===a.pass){
      const newA = { ...a, token: 'token-'+Math.random().toString(36).slice(2,9) }
      localStorage.setItem('admin', JSON.stringify(newA))
      setMsg('Welcome, admin (mock).')
    }else{
      setMsg('Invalid admin credentials')
    }
  }

  return (
    <div className="panel">
      <div className="tabs">
        <button className="on">Login</button>
      </div>
      <div className="grid">
        <div className="row">
          <input placeholder="Admin email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input type="password" placeholder="Password" value={pass} onChange={e=>setPass(e.target.value)} />
          <button className="btn" onClick={login}>Enter</button>
        </div>
        <div className="muted mini">Demo admin: <code>admin@theatrica.io / admin</code></div>
        {msg && <div className="mini">{msg}</div>}
      </div>
    </div>
  )
}
