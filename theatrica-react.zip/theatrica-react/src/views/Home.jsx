import React from 'react'
import { useApp } from '../context/AppContext'
import ProductCard from '../components/ProductCard'

export default function Home(){
  const { products } = useApp()
  const data = products.slice(0,6)
  return (
    <div className="grid">
      <div className="grid" style={{gridTemplateColumns:'2fr 1fr', gap:16}}>
        <div className="panel">
          <h3 style={{margin:'0 0 8px'}}>Now Showing Highlights</h3>
          <div className="catalog">
            {data.map(p => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
        <div className="panel">
          <h3 style={{margin:'0 0 8px'}}>Promos</h3>
          <div className="card">🎁 <b>Family Snack Set</b> 10% off at checkout.</div>
          <div className="card">⚡ <b>Fast Pass</b> add‑on available for premiere night.</div>
          <div className="card">💜 VIP <b>Digital Membership</b> earns 2× points this week.</div>
        </div>
      </div>
      <div className="panel">
        <h3 style={{margin:'0 0 8px'}}>Categories</h3>
        <div className="row">
          <a className="btn sec" href="/catalog?cat=Tickets">Tickets</a>
          <a className="btn sec" href="/catalog?cat=Snacks">Snacks & Beverages</a>
          <a className="btn sec" href="/catalog?cat=Merch">Merch & Collectibles</a>
        </div>
      </div>
    </div>
  )
}
