import React, { useState } from 'react'
import { useApp } from '../context/AppContext'

export default function Account(){
  const { session, login, register, saveProfile, logout } = useApp()
  const [tab, setTab] = useState('login')

  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [name, setName] = useState(session?.name || '')
  const [phone, setPhone] = useState(session?.phone || '')
  const [addr, setAddr] = useState(session?.addr || '')
  const [msg, setMsg] = useState('')

  const doLogin = () => {
    const ok = login(email, pass)
    setMsg(ok ? '' : 'Invalid credentials')
    if(ok) setTab('profile')
  }
  const doRegister = () => {
    const res = register(email, pass || 'demo')
    if(!res.ok) setMsg(res.msg)
    else { setMsg(''); setTab('profile') }
  }
  const doSave = () => { saveProfile({name, addr, phone}); setMsg('Saved ✔') }

  return (
    <div className="panel">
      <div className="tabs">
        <button className={tab==='login'?'on':''} onClick={()=>setTab('login')}>Login</button>
        <button className={tab==='profile'?'on':''} onClick={()=>setTab('profile')}>Profile</button>
        <button className={tab==='wishlist'?'on':''} onClick={()=>setTab('wishlist')}>Wishlist</button>
        <button className={tab==='notifications'?'on':''} onClick={()=>setTab('notifications')}>Notifications</button>
      </div>

      {tab==='login' && (
        <div className="grid">
          <div className="row">
            <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
            <input placeholder="Password" type="password" value={pass} onChange={e=>setPass(e.target.value)} />
            <button className="btn" onClick={doLogin}>Sign in</button>
            <button className="btn sec" onClick={doRegister}>Register</button>
          </div>
          <div className="muted mini">Demo users: <code>user@demo.com / demo</code> or create your own.</div>
          {msg && <div className="mini" style={{color:'#fca5a5'}}>{msg}</div>}
        </div>
      )}

      {tab==='profile' && session && (
        <div className="grid">
          <div className="row">
            <input placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} />
            <input placeholder="Mobile" value={phone} onChange={e=>setPhone(e.target.value)} />
          </div>
          <input placeholder="Default address" value={addr} onChange={e=>setAddr(e.target.value)} />
          <div className="row">
            <button className="btn ok" onClick={doSave}>Save</button>
            <button className="btn bad" onClick={logout}>Sign out</button>
            <span className="right muted mini">{msg}</span>
          </div>
        </div>
      )}

      {tab==='wishlist' && (
        <div className="grid">
          <div className="muted mini">Wishlist coming soon.</div>
        </div>
      )}

      {tab==='notifications' && (
        <div className="grid">
          <div className="muted mini">Notifications are attached to your account when you place an order.</div>
        </div>
      )}
    </div>
  )
}
