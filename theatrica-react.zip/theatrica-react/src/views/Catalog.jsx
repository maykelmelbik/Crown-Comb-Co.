import React, { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext'
import ProductCard from '../components/ProductCard'
import { useSearchParams } from 'react-router-dom'

export default function Catalog(){
  const { products } = useApp()
  const [sp, setSp] = useSearchParams()
  const [cat, setCat] = useState(sp.get('cat') || '')
  const [attr, setAttr] = useState(sp.get('attr') || '')
  const [q, setQ] = useState(sp.get('q') || '')
  const [sort, setSort] = useState('pop')

  const filtered = useMemo(()=>{
    let data = products.filter(p =>
      (!cat || p.cat===cat) &&
      (!attr || p.attr===attr) &&
      (!q || p.name.toLowerCase().includes(q.toLowerCase()))
    )
    const key = ({pop:'id',new:'-id',name:'name',priceAsc:'price',priceDesc:'-price'})[sort]
    data.sort((a,b)=>{
      const k = key.startsWith('-') ? key.slice(1) : key
      const dir = key.startsWith('-') ? -1 : 1
      return (a[k] > b[k] ? 1 : -1) * dir
    })
    return data
  }, [products, cat, attr, q, sort])

  const apply = () => {
    const next = {}
    if(cat) next.cat = cat
    if(attr) next.attr = attr
    if(q) next.q = q
    setSp(next)
  }

  return (
    <div className="grid">
      <div className="panel">
        <div className="row">
          <select value={cat} onChange={e=>setCat(e.target.value)}>
            <option value="">All categories</option>
            <option>Tickets</option><option>Snacks</option><option>Merch</option>
          </select>
          <select value={attr} onChange={e=>setAttr(e.target.value)}>
            <option value="">Attribute (size/seat/type)</option>
            <option value="VIP">VIP</option>
            <option value="Standard">Standard</option>
            <option value="Combo">Combo</option>
          </select>
          <select value={sort} onChange={e=>setSort(e.target.value)}>
            <option value="pop">Sort: Popular</option>
            <option value="new">Sort: New</option>
            <option value="name">Sort: Name</option>
            <option value="priceAsc">Price: Low → High</option>
            <option value="priceDesc">Price: High → Low</option>
          </select>
          <button className="btn" onClick={apply}>Apply</button>
          <input className="right" placeholder="Filter by name..." value={q} onChange={e=>setQ(e.target.value)} />
        </div>
      </div>
      <div className="catalog">
        {filtered.map(p => <ProductCard key={p.id} p={p} />)}
      </div>
    </div>
  )
}
