import React from 'react'
import { useApp } from '../context/AppContext'

export default function Orders(){
  const { orders, products, fmt, session } = useApp()
  const me = session?.email
  const all = orders.filter(o => !me || o.user === me)

  return (
    <div className="panel">
      <h3>Order History & Tracking</h3>
      <table className="table">
        <thead><tr><th>Order</th><th>Items</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>
          {all.map(o => (
            <tr key={o.id}>
              <td>{o.id}<div className="mini muted">{new Date(o.ts).toLocaleString()}</div></td>
              <td>{o.items.map(i=>products.find(p=>p.id===i.pid)?.name + ' ×' + i.qty).join(', ')}</td>
              <td>{fmt(o.total)}</td>
              <td>{o.status}</td>
            </tr>
          ))}
          {!all.length && (
            <tr><td colSpan={4} className="muted">No orders yet.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  )
}
