import React, { useMemo, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useApp } from '../context/AppContext'

export default function Detail(){
  const { pid } = useParams()
  const { products, inventory, fmt, addToCart, reviews, addReview, session } = useApp()
  const p = products.find(x=>x.id===pid)
  const inv = inventory.find(i=>i.pid===pid) || { stock:0, status:'inactive' }
  const [qty, setQty] = useState(1)
  const [note, setNote] = useState('')
  const [stars, setStars] = useState(5)
  const [text, setText] = useState('')

  const myReviews = useMemo(()=>reviews.filter(r=>r.pid===pid), [reviews, pid])

  if(!p) return <div className="panel">Product not found.</div>

  return (
    <div className="grid">
      <div className="panel">
        <div className="row">
          <img src={p.img} style={{width:320,height:220,objectFit:'cover',borderRadius:12,border:'1px solid #1f2937'}} />
          <div style={{flex:1}}>
            <h2 style={{margin:0}}>{p.name}</h2>
            <div className="row"><span className="tag">{p.cat}</span><span className="tag">{p.attr || '—'}</span></div>
            <div className="price" style={{margin:'8px 0'}}>{fmt(p.price)}</div>
            <div className="muted mini">Stock: {inv.stock} • Status: {inv.status}</div>
            <div className="row" style={{marginTop:10}}>
              <input type="number" min="1" value={qty} onChange={e=>setQty(Number(e.target.value)||1)} style={{width:100}} />
              <input placeholder="Seat row, add‑ons, size…" value={note} onChange={e=>setNote(e.target.value)} />
              <button className="btn" onClick={()=>addToCart(p.id, qty, note)}>Add to Cart</button>
              <button className="btn sec" onClick={()=>alert('Wishlist coming soon (login required)')}>♡ Wishlist</button>
            </div>
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>Reviews & Ratings</h3>
        <div>
          {myReviews.length
            ? myReviews.map(r => (
                <div key={r.id} className="card">
                  <b>{'★'.repeat(r.stars)}{'☆'.repeat(5-r.stars)}</b> — {r.text} <span className="muted mini">by {r.user || 'Anon'}</span>
                </div>
              ))
            : <div className="muted mini">No reviews yet. Be the first!</div>}
        </div>
        <div className="card">
          <div className="row">
            <select value={stars} onChange={e=>setStars(Number(e.target.value))}>
              <option value="5">★★★★★</option>
              <option value="4">★★★★☆</option>
              <option value="3">★★★☆☆</option>
              <option value="2">★★☆☆☆</option>
              <option value="1">★☆☆☆☆</option>
            </select>
            <input placeholder="Share your thoughts…" value={text} onChange={e=>setText(e.target.value)} />
            <button className="btn" onClick={()=>{ if(!text.trim()) return alert('Please add a short review.'); addReview(p.id, stars, text.trim()); setText(''); }}>Submit</button>
          </div>
        </div>
      </div>
    </div>
  )
}
