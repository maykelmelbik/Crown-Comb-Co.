import React, { useState } from 'react'

export default function Support(){
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [msg, setMsg] = useState('')
  const [status, setStatus] = useState('')

  const send = () => {
    setStatus('Thanks! We will reply via email.')
  }

  return (
    <div className="panel">
      <h3>Contact & FAQ</h3>
      <div className="grid" style={{gridTemplateColumns:'2fr 1fr', gap:16}}>
        <div className="card">
          <div className="row">
            <input placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} />
            <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          </div>
          <textarea rows={4} placeholder="How can we help?" value={msg} onChange={e=>setMsg(e.target.value)}></textarea>
          <div className="row">
            <button className="btn" onClick={send}>Send</button>
            <span className="muted mini">{status}</span>
          </div>
        </div>
        <div className="grid">
          <div className="card"><b>Refunds</b><br/><span className="muted mini">Requests within 24h of screening are auto‑approved for VIP members.</span></div>
          <div className="card"><b>Delivery</b><br/><span className="muted mini">3PL ETA 30‑60 mins. You’ll get real‑time status updates.</span></div>
          <div className="card"><b>Security</b><br/><span className="muted mini">We follow privacy‑by‑design & mock PCI‑DSS controls.</span></div>
        </div>
      </div>
    </div>
  )
}
