import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'

export default function Cart(){
  const { cart, products, fmt, updateCartQty, updateCartNote, removeFromCart, cartTotal } = useApp()
  const navigate = useNavigate()

  if(!cart.length){
    return (
      <div className="panel">
        <h3>Your Cart</h3>
        <div className="muted">Your cart is empty.</div>
      </div>
    )
  }

  return (
    <div className="grid">
      <div className="panel">
        <h3>Your Cart</h3>
        <div>
          {cart.map(i => {
            const p = products.find(x=>x.id===i.pid)
            return (
              <div key={i.id} className="card row">
                <img src={p.img} style={{width:90,height:70,objectFit:'cover',borderRadius:8,border:'1px solid #1f2937'}} />
                <div style={{flex:1}}>
                  <b>{p.name}</b>
                  <div className="muted mini">{p.cat} • {p.attr || '—'}</div>
                  <input value={i.note || ''} onChange={e=>updateCartNote(i.id, e.target.value)} className="mini" />
                </div>
                <input type="number" min="1" value={i.qty} style={{width:80}} onChange={e=>updateCartQty(i.id, e.target.value)} />
                <div className="price">{fmt(p.price * i.qty)}</div>
                <button className="btn bad" onClick={()=>removeFromCart(i.id)}>Remove</button>
              </div>
            )
          })}
        </div>
        <div className="row" style={{justifyContent:'space-between',marginTop:10}}>
          <div className="muted mini">Tip: quantities & notes are editable.</div>
          <div><b>Subtotal:</b> <span className="price">{fmt(cartTotal)}</span></div>
        </div>
      </div>
      <div className="panel">
        <div className="row">
          <button className="btn ok right" onClick={()=>navigate('/checkout')}>Proceed to Checkout</button>
        </div>
      </div>
    </div>
  )
}
