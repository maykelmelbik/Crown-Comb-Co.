import React from 'react'
import './Theatrica.css'
import { Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './views/Home'
import Catalog from './views/Catalog'
import Detail from './views/Detail'
import Cart from './views/Cart'
import Checkout from './views/Checkout'
import Orders from './views/Orders'
import Support from './views/Support'
import Account from './views/Account'
import Admin from './views/Admin'

export default function App(){
  return (
    <div>
      <header>
        <div className="wrap topbar">
          <Header />
        </div>
      </header>

      <section className="hero">
        <div className="wrap">
          <h1>Book seats. Order snacks. Grab merch.</h1>
          <div className="muted">Seamless from browsing to checkout — built with modular, API‑first architecture ready for AI, AR, wallets and 3PL.</div>
        </div>
      </section>

      <main className="wrap" style={{padding:'18px 16px'}}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/product/:pid" element={<Detail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/support" element={<Support />} />
          <Route path="/account" element={<Account />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </main>

      <Footer />
    </div>
  )
}
