export const store = {
  get: k => JSON.parse(localStorage.getItem(k) || 'null'),
  set: (k, v) => localStorage.setItem(k, JSON.stringify(v)),
  push: (k, v) => { const a = store.get(k) || []; a.push(v); store.set(k, a); },
}

export const fmt = n => '₱' + (Number(n)||0).toLocaleString('en-PH', { minimumFractionDigits: 2 })
export const makeId = () => 'id-' + Math.random().toString(36).slice(2,9)

export function seedIfNeeded(){
  if(store.get('seeded')) return
  const id = makeId
  const products = [
    {id:id(),name:'Movie Ticket — Standard',cat:'Tickets',attr:'Standard',price:280,img:'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Movie Ticket — VIP Recliner',cat:'Tickets',attr:'VIP',price:520,img:'https://images.unsplash.com/photo-1517602302552-471fe67acf66?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Group Ticket Package (4)',cat:'Tickets',attr:'Standard',price:999,img:'https://images.unsplash.com/photo-1498925008800-019c7d59d903?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Fast Pass / Skip‑the‑Line',cat:'Tickets',attr:'VIP',price:120,img:'https://images.unsplash.com/photo-1452697620382-f6543ead73b5?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Regular Popcorn',cat:'Snacks',attr:'',price:120,img:'https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Popcorn + Drink Combo',cat:'Snacks',attr:'Combo',price:199,img:'https://images.unsplash.com/photo-1516214104703-d870798883c5?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Family Snack Set',cat:'Snacks',attr:'Combo',price:499,img:'https://images.unsplash.com/photo-1478147427282-58a87a120781?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Coffee / Hot Chocolate',cat:'Snacks',attr:'',price:130,img:'https://images.unsplash.com/photo-1498804103079-a6351b050096?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Movie T‑Shirt',cat:'Merch',attr:'Standard',price:699,img:'https://images.unsplash.com/photo-1520975940471-7f55f2b8b3a8?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Limited Edition Poster',cat:'Merch',attr:'',price:450,img:'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1200&auto=format&fit=crop'},
    {id:id(),name:'Theatrica Collectible Mug',cat:'Merch',attr:'',price:320,img:'https://images.unsplash.com/photo-1523365280197-f1783db9fe62?q=80&w=1200&auto=format&fit=crop'}
  ]
  store.set('products', products)
  store.set('orders', [])
  store.set('users', [{id:id(),email:'user@demo.com',pass:'demo',name:'Demo User',addr:'',phone:'',wishlist:[],notifs:[]}])
  store.set('admin', {email:'admin@theatrica.io',pass:'admin',token:''})
  store.set('inventory', products.map(p=>({pid:p.id,stock:20,status:'active'})))
  store.set('cms',{About:'We love cinemas.',Contact:'Message us via Support.',FAQ:'VIP gets free refunds.',Privacy:'We respect your data.'})
  store.set('settings',{currency:'PHP',ship:'pickup',pay:'gcash'})
  store.set('audit',[])
  store.set('reviews',[])
  store.set('seeded', true)
}
