import React, { useState } from 'react'
import { Link, NavLink, useNavigate, createSearchParams } from 'react-router-dom'
import { useApp } from '../context/AppContext'

export default function Header(){
  const { cartCount, session } = useApp()
  const [q, setQ] = useState('')
  const navigate = useNavigate()

  const doSearch = () => {
    navigate({ pathname: '/catalog', search: `?${createSearchParams({ q })}` })
  }

  return (
    <>
      <div className="brand"><i></i><span>Theatrica</span></div>
      <div className="row" style={{flex:1, maxWidth:520}}>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search movies, snacks, merch…" />
        <button className="btn sec" onClick={doSearch}>Search</button>
      </div>
      <nav>
        <NavLink to="/">Home</NavLink>
        <NavLink to="/catalog">Shop</NavLink>
        <NavLink to="/cart">Cart ({cartCount})</NavLink>
        <NavLink to="/orders">Orders</NavLink>
        <NavLink to="/support">Support</NavLink>
        <NavLink to="/account">{session ? session.email.split('@')[0] : 'Sign in'}</NavLink>
        <NavLink to="/admin">Admin</NavLink>
      </nav>
    </>
  )
}
