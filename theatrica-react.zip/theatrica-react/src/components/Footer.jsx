import React from 'react'

export default function Footer(){
  return (
    <footer>
      © Theatrica — Smart Cinemas • Built for IT009 Systems Integration & Architecture (modular, API‑first, event‑driven, SOA micro‑features)
    </footer>
  )
}
