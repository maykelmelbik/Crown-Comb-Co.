import React from 'react'
import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'

export default function ProductCard({ p }){
  const { fmt, addToCart } = useApp()
  return (
    <div className="card">
      <img src={p.img} alt="" />
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:8}}>
        <div><b>{p.name}</b><br/><span className="muted mini">{p.cat} • {p.attr || '—'}</span></div>
        <div className="price">{fmt(p.price)}</div>
      </div>
      <div className="row" style={{marginTop:8}}>
        <Link className="btn" to={`/product/${p.id}`}>View</Link>
        <button className="btn sec" onClick={()=>addToCart(p.id,1,'')}>Quick add</button>
      </div>
    </div>
  )
}
