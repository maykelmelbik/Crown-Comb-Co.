import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { store, fmt, makeId, seedIfNeeded } from '../utils/store'

const AppContext = createContext(null)
export const useApp = () => useContext(AppContext)

export function AppProvider({ children }){
  const [products, setProducts] = useState([])
  const [cart, setCart] = useState([])
  const [orders, setOrders] = useState([])
  const [users, setUsers] = useState([])
  const [admin, setAdmin] = useState(null)
  const [inventory, setInventory] = useState([])
  const [cms, setCms] = useState({})
  const [settings, setSettings] = useState({})
  const [reviews, setReviews] = useState([])
  const [session, setSession] = useState(null)

  useEffect(() => {
    seedIfNeeded()
    // initial load from localStorage
    setProducts(store.get('products') || [])
    setCart(store.get('cart') || [])
    setOrders(store.get('orders') || [])
    setUsers(store.get('users') || [])
    setAdmin(store.get('admin') || null)
    setInventory(store.get('inventory') || [])
    setCms(store.get('cms') || {})
    setSettings(store.get('settings') || {})
    setReviews(store.get('reviews') || [])
    setSession(store.get('session') || null)
  }, [])

  const cartCount = useMemo(() => cart.reduce((s,i)=>s+i.qty,0), [cart])
  const cartTotal = useMemo(() => cart.reduce((s,i)=>{
    const p = products.find(x=>x.id===i.pid)
    return s + (p ? p.price * i.qty : 0)
  },0), [cart, products])

  // Actions
  function addToCart(pid, qty=1, note=''){
    const items = [...(store.get('cart') || [])]
    const existing = items.find(i=>i.pid===pid && i.note===note)
    if(existing) existing.qty += qty
    else items.push({id:makeId(), pid, qty, note})
    store.set('cart', items)
    setCart(items)
  }

  function updateCartQty(itemId, qty){
    const items = [...cart]
    const it = items.find(i=>i.id===itemId)
    if(it){ it.qty = Math.max(1, Number(qty)||1) }
    store.set('cart', items)
    setCart(items)
  }

  function updateCartNote(itemId, note){
    const items = [...cart]
    const it = items.find(i=>i.id===itemId)
    if(it){ it.note = note }
    store.set('cart', items)
    setCart(items)
  }

  function removeFromCart(itemId){
    const items = (store.get('cart')||[]).filter(i=>i.id!==itemId)
    store.set('cart', items)
    setCart(items)
  }

  function login(email, pass){
    const u = (store.get('users')||[]).find(x=>x.email===email && x.pass===pass)
    if(!u) return false
    store.set('session', u)
    setSession(u)
    return true
  }

  function register(email, pass='demo'){
    if(!email) return { ok:false, msg:'Enter an email' }
    const users = store.get('users') || []
    if(users.some(u=>u.email===email)) return { ok:false, msg:'User exists' }
    const u = {id:makeId(), email, pass, name:'', addr:'', phone:'', wishlist:[], notifs:[]}
    users.push(u)
    store.set('users', users)
    store.set('session', u)
    setUsers(users)
    setSession(u)
    return { ok:true }
  }

  function saveProfile({name, addr, phone}){
    const s = store.get('session')
    if(!s) return
    const users = store.get('users') || []
    const u = users.find(x=>x.id===s.id)
    Object.assign(u, {name, addr, phone})
    store.set('users', users)
    store.set('session', u)
    setUsers(users)
    setSession(u)
  }

  function logout(){
    localStorage.removeItem('session')
    setSession(null)
  }

  function addReview(pid, stars, text){
    const user = store.get('session')
    const r = { id: makeId(), pid, stars, text, user: user?.email || 'Guest', ts: Date.now() }
    const all = [...(store.get('reviews')||[]), r]
    store.set('reviews', all)
    setReviews(all)
  }

  function placeOrder({ ship, pay }){
    const items = store.get('cart') || []
    if(!items.length) return { ok:false, msg:'Cart is empty.' }
    const order = {
      id: makeId(),
      items,
      total: items.reduce((s,i)=>{
        const p = (store.get('products')||[]).find(x=>x.id===i.pid)
        return s + (p?p.price*i.qty:0)
      },0),
      ship,
      pay,
      status:'Pending',
      ts: Date.now(),
      user: (store.get('session')||{}).email || 'guest'
    }
    // Save order
    const orders = [...(store.get('orders')||[]), order]
    store.set('orders', orders)
    setOrders(orders)
    // Inventory decrement
    const inv = store.get('inventory') || []
    order.items.forEach(i=>{
      const row = inv.find(x=>x.pid===i.pid)
      if(row){
        row.stock = Math.max(0, row.stock - i.qty)
        if(row.stock <= 3){
          // simple audit
          const msg = `ALERT Low stock for ${(store.get('products')||[]).find(p=>p.id===i.pid)?.name}`
          store.push('audit', { id: makeId(), msg, ts: Date.now() })
        }
      }
    })
    store.set('inventory', inv)
    setInventory(inv)
    // Clear cart
    store.set('cart', [])
    setCart([])
    // Notify (mock)
    const users = store.get('users') || []
    const u = users.find(x=>x.email===order.user)
    if(u){
      u.notifs.push({ id: makeId(), title:`Order ${order.id} confirmed`, body:'Thanks! Track status in Orders.', ts: Date.now() })
      store.set('users', users)
      setUsers(users)
    }
    return { ok:true, order }
  }

  const ctx = {
    products, setProducts,
    cart, setCart, cartCount, cartTotal,
    orders, setOrders,
    users, setUsers,
    admin, setAdmin,
    inventory, setInventory,
    cms, setCms,
    settings, setSettings,
    reviews, setReviews,
    session, setSession,
    fmt,
    addToCart, updateCartQty, updateCartNote, removeFromCart,
    login, register, saveProfile, logout,
    addReview, placeOrder
  }

  return <AppContext.Provider value={ctx}>{children}</AppContext.Provider>
}
